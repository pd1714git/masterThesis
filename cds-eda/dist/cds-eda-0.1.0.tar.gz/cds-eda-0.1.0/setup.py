# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cds_eda']

package_data = \
{'': ['*']}

install_requires = \
['DateTime>=4.3,<5.0',
 'matplotlib>=3.3.4,<4.0.0',
 'numpy>=1.20.1,<2.0.0',
 'pandas>=1.2.2,<2.0.0',
 'scipy>=1.6.1,<2.0.0']

setup_kwargs = {
    'name': 'cds-eda',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'pd1714git',
    'author_email': 'pierre-olivier.donnat@polytechnique.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.1,<4.0',
}


setup(**setup_kwargs)
